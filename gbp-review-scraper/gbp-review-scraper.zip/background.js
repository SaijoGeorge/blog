// Background service worker for SEO Saijo GBP Review Scraper

let waitingForReload = {};

// Open side panel when extension icon is clicked
chrome.action.onClicked.addListener(async (tab) => {
  // Open the side panel
  await chrome.sidePanel.open({ tabId: tab.id });

  // Inject content script into the active tab
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  } catch (error) {
    // Content script might already be injected, which is fine
  }
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // If content script says it clicked Reviews and page will reload
  if (message.type === 'page_will_reload') {
    waitingForReload[sender.tab.id] = true;
  }
  return false;
});

// When page finishes loading, re-inject script if we're waiting for reload
chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId === 0 && waitingForReload[details.tabId]) {
    // Clear the flag
    delete waitingForReload[details.tabId];

    // Small delay to let page settle
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Re-inject content script
    try {
      await chrome.scripting.executeScript({
        target: { tabId: details.tabId },
        files: ['content.js']
      });
    } catch (error) {
      console.error('Failed to re-inject content script:', error);
    }
  }
});
