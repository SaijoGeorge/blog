// Background service worker for SEO Saijo GBP Review Scraper

// Open side panel when extension icon is clicked
chrome.action.onClicked.addListener(async (tab) => {
  // Open the side panel
  await chrome.sidePanel.open({ tabId: tab.id });

  // Inject content script into the active tab
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  } catch (error) {
    // Content script might already be injected, which is fine
  }
});

// Listen for messages from content script and forward to side panel
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Messages from content script will be automatically received by side panel
  // No need to explicitly forward in MV3
  return false;
});
