// Content script for SEO Saijo GBP Review Scraper
// Migrated from bookmarklet - all console logs removed

(function() {
  // Detect page type and variant
  const isSearchPage = /google\.[a-z.]+\/search/.test(window.location.href);
  const isMapsPage = /google\.[a-z.]+\/maps/.test(window.location.href);

  if (!isSearchPage && !isMapsPage) {
    sendError(
      'This tool only works on Google Search or Google Maps pages.\n\nPlease navigate to a business listing on:\n- google.com/search\n- google.com/maps'
    );
    return;
  }

  // Check if it's a knowledge graph on search page
  let pageType = 'search';
  let isKnowledgeGraph = false;
  let reviewsModalOpen = false;

  if (isSearchPage) {
    const rhsDiv = document.getElementById('rhs');
    const kpDiv = document.querySelector('.kp-wholepage');

    if (rhsDiv && kpDiv) {
      isKnowledgeGraph = true;
      pageType = 'search-kg';

      // Check if we're already on the reviews page (after clicking Reviews caused page reload)
      // Look for review containers or "Newest" sort option to detect this
      const reviewContainers = document.querySelectorAll('.bwb7ce');
      const newestButton = document.evaluate(
        "//*[@role='radio' or @role='button'][contains(., 'Newest')]",
        document,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null
      ).singleNodeValue;

      if (reviewContainers.length > 0 || newestButton) {
        reviewsModalOpen = true;
      }
    }
  } else if (isMapsPage) {
    pageType = 'maps';
  }

  // CONFIG - Edit these when Google breaks things
  const CONFIG = {
    search: {
      selectors: {
        reviewsTab: "//a[@role='tab' and .//span[normalize-space()='Reviews']]",
        newestSort: "//span[normalize-space()='Newest']/ancestor::div[@role='radio']",
        scrollContainer: "#osuid_0",
        reviewContainer: "//div[contains(@class,'bwb7ce') and @jsname='ShBeI']",
        reviewerName: ".//div[contains(@class,'Vpc5Fe')]",
        starRating: ".//div[contains(@class,'dHX2k') and @role='img']/@aria-label",
        reviewDate: ".//span[contains(@class,'y3Ibjb')]",
        reviewContent: ".//div[contains(@class,'OA1nbd')]",
        reviewResponse: ".//div[contains(@class,'KmCjbd')]",
        moreButtons: "//div[contains(@class,'bwb7ce')]//a[normalize-space()='More'] | //div[contains(@class,'bwb7ce')]//*[starts-with(@aria-label, 'Read more') and substring(@aria-label, string-length(@aria-label) - 5) = 'review']"
      }
    },
    'search-kg': {
      selectors: {
        reviewsSpan: "//div[contains(@ssk, '_local_action')]//span[normalize-space()='Reviews']",
        newestSpan: "//*[@role='radio' or @role='button'][contains(., 'Newest')]",
        moreUserReviews: "//*[@role='button'][contains(., 'More') and contains(., 'reviews')]",
        reviewContainer: "//div[@jsname='GmP9w']//div[contains(@class,'bwb7ce')]",
        reviewerName: ".//div[contains(@class,'Vpc5Fe')]",
        starRating: ".//div[contains(@class,'dHX2k') and @role='img']/@aria-label",
        reviewDate: ".//span[contains(@class,'y3Ibjb')]",
        reviewContent: ".//div[contains(@class,'OA1nbd')]",
        reviewResponse: ".//div[contains(@class,'KmCjbd')]",
        moreButtons: "//div[contains(@class,'bwb7ce')]//a[normalize-space()='More' and @role='button'] | //div[contains(@class,'bwb7ce')]//*[starts-with(@aria-label, 'Read more') and substring(@aria-label, string-length(@aria-label) - 5) = 'review']"
      }
    },
    maps: {
      selectors: {
        reviewsTab: "//button[@role='tab' and .//div[normalize-space()='Reviews']]",
        sortButton: "//button[@aria-label='Sort reviews']",
        newestOption: "//*[@role='menuitem' or @role='menuitemradio'][contains(., 'Newest')]",
        scrollContainer: "//div[@role='feed' and contains(@class, 'm6QErb')]",
        reviewContainer: "//div[contains(@class,'jftiEf')]",
        reviewerName: ".//button[contains(@jsaction,'review.reviewerLink')]//div[contains(@class,'d4r55')]",
        starRating: ".//span[@role='img' and contains(@aria-label,'star')]/@aria-label",
        reviewDate: ".//span[contains(@class,'rsqaWe')]",
        reviewContent: ".//span[contains(@class,'wiI7pd')]",
        reviewResponse: ".//div[contains(@class,'CDe7pd')]//div[contains(@class,'wiI7pd')]",
        moreButtons: "//button[contains(text(),'More') or contains(@aria-label,'More')]"
      }
    },
    timing: {
      initialWait: 2000,
      scrollWait: 1500,
      clickWait: 300,
      moreButtonTimeout: 3000,
      moreUserReviewsWait: 2000
    }
  };

  const SELECTORS = CONFIG[pageType].selectors;

  // Helper: Send progress update to side panel
  function sendProgress(percent, text) {
    chrome.runtime.sendMessage({
      type: 'progress',
      percent: percent,
      text: text
    });
  }

  // Helper: Send error to side panel
  function sendError(message, details = '') {
    chrome.runtime.sendMessage({
      type: 'error',
      message: message,
      details: details
    });
  }

  // Helper: Send reviews data to side panel
  function sendReviews(reviews) {
    chrome.runtime.sendMessage({
      type: 'reviews',
      data: reviews
    });
  }

  // Helper: XPath evaluator
  function getByXPath(xpath, context = document) {
    const result = document.evaluate(xpath, context, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    const nodes = [];
    for (let i = 0; i < result.snapshotLength; i++) {
      nodes.push(result.snapshotItem(i));
    }
    return nodes;
  }

  // Helper: Get XPath attribute value
  function getXPathValue(xpath, context = document) {
    const result = document.evaluate(xpath, context, null, XPathResult.ANY_TYPE, null);
    const attr = result.iterateNext();
    return attr ? attr.value : '';
  }

  // Helper: Wait for element
  async function waitForElement(xpath, timeout = 5000) {
    const startTime = Date.now();
    while (Date.now() - startTime < timeout) {
      const elements = getByXPath(xpath);
      if (elements.length > 0) return elements[0];
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    throw new Error(`Element not found: ${xpath}`);
  }

  // Helper: Sleep
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Helper: Escape HTML
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Helper: Simulate a real mouse click (needed for Google Maps jsaction handlers)
  function simulateClick(element) {
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
    element.dispatchEvent(new PointerEvent('pointerdown', opts));
    element.dispatchEvent(new MouseEvent('mousedown', opts));
    element.dispatchEvent(new PointerEvent('pointerup', opts));
    element.dispatchEvent(new MouseEvent('mouseup', opts));
    element.dispatchEvent(new MouseEvent('click', opts));
  }

  // Helper: Check if element is clickable
  function isElementClickable(element) {
    if (!element || element.offsetParent === null) return false;

    const rect = element.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;

    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;

    return true;
  }

  // Step 1: Click Reviews tab/span
  async function clickReviewsTab() {
    if (pageType === 'search-kg' && !reviewsModalOpen) {
      // Try to click the Reviews button (it will cause page reload)
      sendProgress(10, 'Looking for Reviews button...');

      try {
        const reviewsElement = await waitForElement(SELECTORS.reviewsSpan, 3000);

        sendProgress(12, 'Clicking Reviews button (page will reload)...');

        // Notify background script that page will reload
        chrome.runtime.sendMessage({ type: 'page_will_reload' });

        // Click the Reviews button
        reviewsElement.click();

        // Show progress message - background script will re-inject after reload
        sendProgress(15, 'Page reloading... extension will continue automatically');

        // Wait for page reload - background script will re-inject content.js
        await new Promise(() => {});
      } catch (e) {
        if (e.message === 'Page reloading after clicking Reviews') {
          throw e;
        }
        sendError(
          'Could not find the Reviews button.',
          'Error: ' + e.message + '\n\nPlease manually click the "Reviews" button, then run the extension again.'
        );
        throw new Error('Reviews button not found');
      }
    }

    if (pageType === 'search-kg' && reviewsModalOpen) {
      sendProgress(15, 'Reviews page detected, continuing...');
      await sleep(500);
      return;
    }

    sendProgress(10, 'Finding the Reviews tab...');
    const tab = await waitForElement(SELECTORS.reviewsTab);
    tab.click();
    sendProgress(15, 'Clicked Reviews tab, waiting for content to load...');
    await sleep(CONFIG.timing.initialWait);
  }

  // Step 2: Click Newest sort
  async function clickNewestSort() {
    if (pageType === 'search') {
      sendProgress(20, 'Looking for the Newest sort option...');
      const sortBtn = await waitForElement(SELECTORS.newestSort);
      sortBtn.click();
      sendProgress(25, 'Sorting by newest reviews...');
      await sleep(CONFIG.timing.initialWait);
    } else if (pageType === 'search-kg') {
      sendProgress(20, 'Looking for the Newest span...');
      const newestSpan = await waitForElement(SELECTORS.newestSpan);
      newestSpan.click();
      sendProgress(25, 'Sorting by newest reviews...');
      await sleep(CONFIG.timing.initialWait);
    } else {
      sendProgress(20, 'Looking for the Sort button...');
      const sortBtn = await waitForElement(SELECTORS.sortButton);

      // Try multiple click strategies — Google Maps jsaction may block some
      const clickStrategies = [
        () => sortBtn.click(),
        () => simulateClick(sortBtn),
        () => { sortBtn.focus(); sortBtn.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); },
        () => { sortBtn.focus(); sortBtn.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', code: 'Space', keyCode: 32, which: 32, bubbles: true, cancelable: true })); sortBtn.dispatchEvent(new KeyboardEvent('keyup', { key: ' ', code: 'Space', keyCode: 32, which: 32, bubbles: true, cancelable: true })); }
      ];

      let newestBtn = null;
      for (let i = 0; i < clickStrategies.length; i++) {
        sendProgress(21, `Trying to open sort menu (attempt ${i + 1}/${clickStrategies.length})...`);
        clickStrategies[i]();
        await sleep(800);

        // Check if menu opened by looking for a visible "Newest" option
        const options = getByXPath(SELECTORS.newestOption);
        for (const opt of options) {
          if (isElementClickable(opt)) {
            newestBtn = opt;
            break;
          }
        }
        if (newestBtn) break;
      }

      if (!newestBtn) throw new Error('Could not open the Sort menu. The sort button was found but none of the click methods opened the dropdown.');
      sendProgress(23, 'Clicking Newest option...');
      newestBtn.click();
      simulateClick(newestBtn);
      sendProgress(25, 'Sorting by newest reviews...');
      await sleep(CONFIG.timing.initialWait);
    }
  }

  // Step 3: Scroll to load all reviews OR click "More user reviews"
  async function scrollToLoadAll() {
    if (pageType === 'search-kg') {
      sendProgress(30, 'Looking for "More user reviews" button...');
      let clickCount = 0;
      let maxClicks = 100;

      while (clickCount < maxClicks) {
        const moreButtons = getByXPath(SELECTORS.moreUserReviews);

        if (moreButtons.length === 0) {
          sendProgress(60, `Loaded all reviews (clicked ${clickCount} times)`);
          break;
        }

        try {
          moreButtons[0].click();
          clickCount++;

          const progress = Math.min(30 + (clickCount * 0.3), 55);
          sendProgress(progress, `Loading more reviews... (clicked ${clickCount} times)`);

          await sleep(CONFIG.timing.moreUserReviewsWait);
        } catch (e) {
          break;
        }
      }

      if (clickCount >= maxClicks) {
        sendProgress(60, `Reached safety limit of ${maxClicks} clicks`);
      }

      return;
    }

    sendProgress(30, 'Starting to scroll and load all reviews...');

    let container;
    if (pageType === 'search') {
      container = document.querySelector(SELECTORS.scrollContainer);
    } else {
      // Find a review element and walk up to its nearest scrollable ancestor
      const reviews = getByXPath(SELECTORS.reviewContainer);
      if (reviews.length > 0) {
        let el = reviews[0].parentElement;
        while (el && el !== document.body) {
          const style = window.getComputedStyle(el);
          if ((style.overflowY === 'auto' || style.overflowY === 'scroll') && el.scrollHeight > el.clientHeight) {
            container = el;
            break;
          }
          el = el.parentElement;
        }
      }
      // Fallback to XPath selector
      if (!container) {
        const containers = getByXPath(SELECTORS.scrollContainer);
        if (containers.length > 0) {
          container = containers[0];
        }
      }
    }

    if (!container) {
      throw new Error('Scroll container not found. Unable to locate the reviews scroll area.');
    }

    let previousHeight = 0;
    let stableCount = 0;
    let scrollAttempts = 0;
    const maxScrolls = 200;

    while (stableCount < 5 && scrollAttempts < maxScrolls) {
      container.scrollBy(0, 3000);
      scrollAttempts++;
      await sleep(2000);

      const currentHeight = container.scrollHeight;
      if (currentHeight === previousHeight) {
        stableCount++;
      } else {
        stableCount = 0;
      }
      previousHeight = currentHeight;

      const progress = Math.min(30 + (scrollAttempts * 0.15), 55);
      sendProgress(progress, `Scrolling to load reviews... (${scrollAttempts} scrolls, height: ${currentHeight}px)`);
    }

    if (scrollAttempts >= maxScrolls) {
      sendProgress(60, `Reached safety limit of ${maxScrolls} scrolls`);
    } else {
      sendProgress(60, 'All reviews loaded via scrolling');
    }
  }

  // Step 4: Click all "More" buttons
  async function expandAllReviews() {
    sendProgress(65, 'Looking for truncated reviews to expand...');
    let clickedCount = 0;

    while (true) {
      const moreButtons = getByXPath(SELECTORS.moreButtons);

      if (moreButtons.length === 0) {
        break;
      }

      let clickedThisRound = 0;
      for (const btn of moreButtons) {
        try {
          if (isElementClickable(btn)) {
            btn.click();
            clickedCount++;
            clickedThisRound++;
            await sleep(500);
          }
        } catch (e) {
          // Ignore click failures
        }
      }

      const progress = Math.min(65 + (clickedCount * 0.15), 75);
      sendProgress(progress, `Expanding reviews... (clicked ${clickedCount} "More" buttons)`);

      if (clickedThisRound === 0) {
        break;
      }

      await sleep(1000);
    }

    sendProgress(80, clickedCount > 0 ? `Expanded ${clickedCount} truncated reviews` : 'No truncated reviews found');
  }

  // Step 5: Extract review data
  function extractReviews() {
    sendProgress(85, 'Extracting review data from the page...');
    const reviewContainers = getByXPath(SELECTORS.reviewContainer);

    if (reviewContainers.length === 0) {
      throw new Error('No review containers found. Unable to locate reviews on the page.');
    }

    const reviews = [];

    reviewContainers.forEach((container, index) => {
      try {
        const nameNodes = getByXPath(SELECTORS.reviewerName, container);
        const dateNodes = getByXPath(SELECTORS.reviewDate, container);
        const contentNodes = getByXPath(SELECTORS.reviewContent, container);
        const responseNodes = getByXPath(SELECTORS.reviewResponse, container);
        const ratingValue = getXPathValue(SELECTORS.starRating, container);

        const review = {
          name: nameNodes[0]?.textContent?.trim() || '',
          rating: ratingValue || '',
          date: dateNodes[0]?.textContent?.trim() || '',
          content: contentNodes[0]?.textContent?.trim() || '',
          response: responseNodes[0]?.textContent?.trim() || ''
        };

        // Validate essential fields are present
        if (!review.name || !review.rating || !review.date) {
          // Skip this review - incomplete data indicates content not fully loaded
          return;
        }

        reviews.push(review);

        if (index % 10 === 0) {
          const progress = Math.min(85 + ((index / reviewContainers.length) * 10), 95);
          sendProgress(progress, `Extracting review data... (${index + 1}/${reviewContainers.length})`);
        }
      } catch (e) {
        // Skip failed review extraction
      }
    });

    sendProgress(100, `Successfully extracted ${reviews.length} reviews!`);
    return reviews;
  }

  // Main execution
  async function run() {
    try {
      sendProgress(0, `Starting review extraction (${pageType} page)...`);
      await sleep(500);

      await clickReviewsTab();
      await clickNewestSort();
      await scrollToLoadAll();

      // Wait for lazy-loaded content to render
      sendProgress(62, 'Waiting for all content to render...');
      await sleep(2000);

      await expandAllReviews();

      // Wait for expanded content to fully render
      sendProgress(82, 'Ensuring all expanded content is loaded...');
      await sleep(1500);

      const reviews = extractReviews();

      await sleep(500);
      sendReviews(reviews);
    } catch (error) {
      sendError(
        error.message || 'An unexpected error occurred while extracting reviews.',
        error.stack || error.toString()
      );
    }
  }

  run();
})();
