// Content script for SEO Saijo GBP Review Scraper
// Migrated from bookmarklet - all console logs removed

(function() {
  // Detect page type and variant
  const isSearchPage = /google\.[a-z.]+\/search/.test(window.location.href);
  const isMapsPage = /google\.[a-z.]+\/maps/.test(window.location.href);

  if (!isSearchPage && !isMapsPage) {
    sendError(
      'This tool only works on Google Search or Google Maps pages.\n\nPlease navigate to a business listing on:\n- google.com/search\n- google.com/maps'
    );
    return;
  }

  // Check if it's a knowledge graph on search page
  let pageType = 'search';
  let isKnowledgeGraph = false;
  let reviewsModalOpen = false;

  if (isSearchPage) {
    const rhsDiv = document.getElementById('rhs');
    const kpDiv = document.querySelector('.kp-wholepage');
    const gmP9wDiv = document.querySelector('[jsname="GmP9w"]');

    if (rhsDiv && kpDiv) {
      isKnowledgeGraph = true;
      pageType = 'search-kg';

      if (gmP9wDiv) {
        reviewsModalOpen = true;
      }
    }
  } else if (isMapsPage) {
    pageType = 'maps';
  }

  // CONFIG - Edit these when Google breaks things
  const CONFIG = {
    search: {
      selectors: {
        reviewsTab: "//a[@role='tab' and .//span[normalize-space()='Reviews']]",
        newestSort: "//span[normalize-space()='Newest']/ancestor::div[@role='radio']",
        scrollContainer: "#osuid_0",
        reviewContainer: "//div[contains(@class,'bwb7ce') and @jsname='ShBeI']",
        reviewerName: ".//div[contains(@class,'Vpc5Fe')]",
        starRating: ".//div[contains(@class,'dHX2k') and @role='img']/@aria-label",
        reviewDate: ".//span[contains(@class,'y3Ibjb')]",
        reviewContent: ".//div[contains(@class,'OA1nbd')]",
        reviewResponse: ".//div[contains(@class,'KmCjbd')]",
        moreButtons: "//a[normalize-space()='More']"
      }
    },
    'search-kg': {
      selectors: {
        reviewsSpan: "//div[@id='rhs']//span[normalize-space()='Reviews']",
        newestSpan: "//span[normalize-space()='Newest']",
        moreUserReviews: "//span[normalize-space()='More user reviews']",
        reviewContainer: "//div[@jsname='GmP9w']//div[contains(@class,'bwb7ce')]",
        reviewerName: ".//div[contains(@class,'Vpc5Fe')]",
        starRating: ".//div[contains(@class,'dHX2k') and @role='img']/@aria-label",
        reviewDate: ".//span[contains(@class,'y3Ibjb')]",
        reviewContent: ".//div[contains(@class,'OA1nbd')]",
        reviewResponse: ".//div[contains(@class,'KmCjbd')]",
        moreButtons: "//a[normalize-space()='More' and @role='button']"
      }
    },
    maps: {
      selectors: {
        reviewsTab: "//button[@role='tab' and .//div[normalize-space()='Reviews']]",
        sortButton: "//span[contains(text(), 'Sort')]",
        newestOption: "//div[contains(text(), 'Newest')]",
        scrollContainer: "//div[@class='m6QErb DxyBCb kA9KIf dS8AEf XiKgde ']",
        reviewContainer: "//div[@class='m6QErb DxyBCb kA9KIf dS8AEf XiKgde ']//div[contains(@class,'jftiEf')]",
        reviewerName: ".//button[contains(@jsaction,'review.reviewerLink')]//div[contains(@class,'d4r55')]",
        starRating: ".//span[@role='img' and contains(@aria-label,'star')]/@aria-label",
        reviewDate: ".//span[contains(@class,'rsqaWe')]",
        reviewContent: ".//span[contains(@class,'wiI7pd')]",
        reviewResponse: ".//div[contains(@class,'CDe7pd')]//div[contains(@class,'wiI7pd')]",
        moreButtons: "//button[contains(text(),'More') or contains(@aria-label,'More')]"
      }
    },
    timing: {
      initialWait: 2000,
      scrollWait: 1500,
      clickWait: 300,
      moreButtonTimeout: 3000,
      moreUserReviewsWait: 2000
    }
  };

  const SELECTORS = CONFIG[pageType].selectors;

  // Helper: Send progress update to side panel
  function sendProgress(percent, text) {
    chrome.runtime.sendMessage({
      type: 'progress',
      percent: percent,
      text: text
    });
  }

  // Helper: Send error to side panel
  function sendError(message, details = '') {
    chrome.runtime.sendMessage({
      type: 'error',
      message: message,
      details: details
    });
  }

  // Helper: Send reviews data to side panel
  function sendReviews(reviews) {
    chrome.runtime.sendMessage({
      type: 'reviews',
      data: reviews
    });
  }

  // Helper: XPath evaluator
  function getByXPath(xpath, context = document) {
    const result = document.evaluate(xpath, context, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    const nodes = [];
    for (let i = 0; i < result.snapshotLength; i++) {
      nodes.push(result.snapshotItem(i));
    }
    return nodes;
  }

  // Helper: Get XPath attribute value
  function getXPathValue(xpath, context = document) {
    const result = document.evaluate(xpath, context, null, XPathResult.ANY_TYPE, null);
    const attr = result.iterateNext();
    return attr ? attr.value : '';
  }

  // Helper: Wait for element
  async function waitForElement(xpath, timeout = 5000) {
    const startTime = Date.now();
    while (Date.now() - startTime < timeout) {
      const elements = getByXPath(xpath);
      if (elements.length > 0) return elements[0];
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    throw new Error(`Element not found: ${xpath}`);
  }

  // Helper: Sleep
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Helper: Escape HTML
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Step 1: Click Reviews tab/span
  async function clickReviewsTab() {
    if (pageType === 'search-kg' && !reviewsModalOpen) {
      // Try to automatically click the Reviews span
      sendProgress(10, 'Attempting to click Reviews button...');

      try {
        const reviewsSpan = await waitForElement(SELECTORS.reviewsSpan, 3000);

        // Try to find the clickable parent (button, a, or div with click handler)
        let clickableElement = reviewsSpan;
        let parent = reviewsSpan.parentElement;
        while (parent && parent !== document.body) {
          const tagName = parent.tagName.toLowerCase();
          if (tagName === 'button' || tagName === 'a' || parent.hasAttribute('jsaction') || parent.getAttribute('role') === 'button') {
            clickableElement = parent;
            break;
          }
          parent = parent.parentElement;
        }

        // Click the element
        clickableElement.click();
        sendProgress(12, 'Clicked Reviews button, waiting for modal...');

        // Wait for modal to be injected into DOM (it's added via JS)
        // Use waitForElement which polls until element appears
        await waitForElement("//div[@jsname='GmP9w']", 5000);

        reviewsModalOpen = true;
        sendProgress(15, 'Reviews modal opened successfully!');
        await sleep(500);
        return;
      } catch (e) {
        // Could not find Reviews span or modal didn't appear
        sendError(
          'Please manually click the "Reviews" button on the page first, then click the extension icon again.',
          'Could not locate Reviews button or modal did not appear. Error: ' + e.message
        );
        throw new Error('Reviews modal not open on knowledge graph page');
      }
    }

    if (pageType === 'search-kg' && reviewsModalOpen) {
      sendProgress(15, 'Reviews modal detected, continuing...');
      await sleep(500);
      return;
    }

    sendProgress(10, 'Finding the Reviews tab...');
    const tab = await waitForElement(SELECTORS.reviewsTab);
    tab.click();
    sendProgress(15, 'Clicked Reviews tab, waiting for content to load...');
    await sleep(CONFIG.timing.initialWait);
  }

  // Step 2: Click Newest sort
  async function clickNewestSort() {
    if (pageType === 'search') {
      sendProgress(20, 'Looking for the Newest sort option...');
      const sortBtn = await waitForElement(SELECTORS.newestSort);
      sortBtn.click();
      sendProgress(25, 'Sorting by newest reviews...');
      await sleep(CONFIG.timing.initialWait);
    } else if (pageType === 'search-kg') {
      sendProgress(20, 'Looking for the Newest span...');
      const newestSpan = await waitForElement(SELECTORS.newestSpan);
      newestSpan.click();
      sendProgress(25, 'Sorting by newest reviews...');
      await sleep(CONFIG.timing.initialWait);
    } else {
      sendProgress(20, 'Looking for the Sort button...');
      const sortBtn = await waitForElement(SELECTORS.sortButton);
      sortBtn.click();
      await sleep(500);
      sendProgress(22, 'Clicking Newest option...');
      const newestBtn = await waitForElement(SELECTORS.newestOption);
      newestBtn.click();
      sendProgress(25, 'Sorting by newest reviews...');
      await sleep(CONFIG.timing.initialWait);
    }
  }

  // Step 3: Scroll to load all reviews OR click "More user reviews"
  async function scrollToLoadAll() {
    if (pageType === 'search-kg') {
      sendProgress(30, 'Looking for "More user reviews" button...');
      let clickCount = 0;
      let maxClicks = 100;

      while (clickCount < maxClicks) {
        const moreButtons = getByXPath(SELECTORS.moreUserReviews);

        if (moreButtons.length === 0) {
          sendProgress(60, `Loaded all reviews (clicked ${clickCount} times)`);
          break;
        }

        try {
          moreButtons[0].click();
          clickCount++;

          const progress = Math.min(30 + (clickCount * 0.3), 55);
          sendProgress(progress, `Loading more reviews... (clicked ${clickCount} times)`);

          await sleep(CONFIG.timing.moreUserReviewsWait);
        } catch (e) {
          break;
        }
      }

      if (clickCount >= maxClicks) {
        sendProgress(60, `Reached safety limit of ${maxClicks} clicks`);
      }

      return;
    }

    sendProgress(30, 'Starting to scroll and load all reviews...');

    let container;
    if (pageType === 'search') {
      container = document.querySelector(SELECTORS.scrollContainer);
    } else {
      const containers = getByXPath(SELECTORS.scrollContainer);
      if (containers.length > 0) {
        container = containers[0];
      }
    }

    if (!container) {
      throw new Error('Scroll container not found. Unable to locate the reviews scroll area.');
    }

    let previousHeight = 0;
    let stableCount = 0;
    let scrollAttempts = 0;

    while (stableCount < 3) {
      container.scrollTop = container.scrollHeight;
      await sleep(CONFIG.timing.scrollWait);

      const currentHeight = container.scrollHeight;
      if (currentHeight === previousHeight) {
        stableCount++;
      } else {
        stableCount = 0;
        scrollAttempts++;
      }
      previousHeight = currentHeight;

      const progress = Math.min(30 + (scrollAttempts * 2), 55);
      sendProgress(progress, `Scrolling to load reviews... (${scrollAttempts} scrolls, height: ${currentHeight}px)`);
    }

    sendProgress(60, 'All reviews loaded via scrolling');
  }

  // Step 4: Click all "More" buttons
  async function expandAllReviews() {
    sendProgress(65, 'Looking for truncated reviews to expand...');
    let clickedCount = 0;
    let attempts = 0;
    const maxAttempts = 5;

    while (attempts < maxAttempts) {
      const moreButtons = getByXPath(SELECTORS.moreButtons);

      if (moreButtons.length === 0) {
        break;
      }

      let clickedThisRound = 0;
      for (const btn of moreButtons) {
        try {
          if (btn.offsetParent !== null) {
            btn.click();
            clickedCount++;
            clickedThisRound++;
            await sleep(CONFIG.timing.clickWait);
          }
        } catch (e) {
          // Ignore click failures
        }
      }

      const progress = Math.min(65 + (clickedCount * 0.5), 75);
      sendProgress(progress, `Expanding reviews... (clicked ${clickedCount} "More" buttons)`);

      if (clickedThisRound === 0) {
        break;
      }

      await sleep(CONFIG.timing.moreButtonTimeout);
      attempts++;
    }

    sendProgress(80, clickedCount > 0 ? `Expanded ${clickedCount} truncated reviews` : 'No truncated reviews found');
  }

  // Step 5: Extract review data
  function extractReviews() {
    sendProgress(85, 'Extracting review data from the page...');
    const reviewContainers = getByXPath(SELECTORS.reviewContainer);

    if (reviewContainers.length === 0) {
      throw new Error('No review containers found. Unable to locate reviews on the page.');
    }

    const reviews = [];

    reviewContainers.forEach((container, index) => {
      try {
        const nameNodes = getByXPath(SELECTORS.reviewerName, container);
        const dateNodes = getByXPath(SELECTORS.reviewDate, container);
        const contentNodes = getByXPath(SELECTORS.reviewContent, container);
        const responseNodes = getByXPath(SELECTORS.reviewResponse, container);
        const ratingValue = getXPathValue(SELECTORS.starRating, container);

        const review = {
          name: nameNodes[0]?.textContent?.trim() || '',
          rating: ratingValue || '',
          date: dateNodes[0]?.textContent?.trim() || '',
          content: contentNodes[0]?.textContent?.trim() || '',
          response: responseNodes[0]?.textContent?.trim() || ''
        };

        reviews.push(review);

        if (index % 10 === 0) {
          const progress = Math.min(85 + ((index / reviewContainers.length) * 10), 95);
          sendProgress(progress, `Extracting review data... (${index + 1}/${reviewContainers.length})`);
        }
      } catch (e) {
        // Skip failed review extraction
      }
    });

    sendProgress(100, `Successfully extracted ${reviews.length} reviews!`);
    return reviews;
  }

  // Main execution
  async function run() {
    try {
      sendProgress(0, `Starting review extraction (${pageType} page)...`);
      await sleep(500);

      await clickReviewsTab();
      await clickNewestSort();
      await scrollToLoadAll();
      await expandAllReviews();
      const reviews = extractReviews();

      await sleep(500);
      sendReviews(reviews);
    } catch (error) {
      sendError(
        error.message || 'An unexpected error occurred while extracting reviews.',
        error.stack || error.toString()
      );
    }
  }

  run();
})();
