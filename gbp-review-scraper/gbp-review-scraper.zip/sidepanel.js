// Side panel JavaScript for SEO Saijo GBP Review Scraper

let reviewsData = null;

// DOM elements
const contentScroll = document.querySelector('.content-scroll');
const welcomeMessage = document.getElementById('welcome-message');
const progressContainer = document.getElementById('progress-container');
const progressBar = document.getElementById('progress-bar');
const progressText = document.getElementById('progress-text');
const errorContainer = document.getElementById('error-container');
const errorMessage = document.getElementById('error-message');
const errorDetails = document.getElementById('error-details');
const resultsContainer = document.getElementById('results-container');
const resultsBody = document.getElementById('results-body');
const downloadContainer = document.getElementById('download-container');
const downloadBtn = document.getElementById('download-btn');

// Hide welcome message initially
welcomeMessage.style.display = 'none';

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'progress') {
    handleProgress(message.percent, message.text);
  } else if (message.type === 'reviews') {
    handleReviews(message.data);
  } else if (message.type === 'error') {
    handleError(message.message, message.details);
  }
});

// Handle progress updates
function handleProgress(percent, text) {
  contentScroll.style.display = 'block';
  welcomeMessage.style.display = 'none';
  progressContainer.style.display = 'block';
  errorContainer.style.display = 'none';
  resultsContainer.style.display = 'none';
  downloadContainer.style.display = 'none';

  progressBar.style.width = percent + '%';
  progressText.textContent = text;
}

// Handle reviews data
function handleReviews(reviews) {
  reviewsData = reviews;

  // Hide progress/content-scroll, show results
  contentScroll.style.display = 'none';
  resultsContainer.style.display = 'flex';
  downloadContainer.style.display = 'block';

  // Update download button text with count
  downloadBtn.textContent = `Download CSV (${reviews.length} reviews)`;

  // Populate table
  resultsBody.innerHTML = '';

  reviews.forEach(review => {
    const row = document.createElement('tr');

    const nameCell = document.createElement('td');
    nameCell.textContent = review.name;

    const ratingCell = document.createElement('td');
    ratingCell.textContent = review.rating;

    const dateCell = document.createElement('td');
    dateCell.textContent = review.date;
    dateCell.style.whiteSpace = 'nowrap';

    const contentCell = document.createElement('td');
    contentCell.className = 'review-content';
    contentCell.textContent = review.content;

    const responseCell = document.createElement('td');
    responseCell.className = 'response-content';
    responseCell.textContent = review.response;

    row.appendChild(nameCell);
    row.appendChild(ratingCell);
    row.appendChild(dateCell);
    row.appendChild(contentCell);
    row.appendChild(responseCell);

    resultsBody.appendChild(row);
  });
}

// Handle errors
function handleError(message, details) {
  contentScroll.style.display = 'block';
  progressContainer.style.display = 'none';
  resultsContainer.style.display = 'none';
  downloadContainer.style.display = 'none';
  errorContainer.style.display = 'block';

  errorMessage.textContent = message;

  if (details) {
    errorDetails.textContent = 'Technical details: ' + details;
    errorDetails.style.display = 'block';
  } else {
    errorDetails.style.display = 'none';
  }
}

// CSV escape helper
function csvEscape(text) {
  if (!text) return '""';
  text = text.toString().replace(/"/g, '""');
  return `"${text}"`;
}

// Download CSV
function downloadCSV() {
  if (!reviewsData || reviewsData.length === 0) {
    return;
  }

  const headers = ['Name', 'Rating', 'Date', 'Review', 'Response'];
  const csvContent = [
    headers.join(','),
    ...reviewsData.map(r => [
      csvEscape(r.name),
      csvEscape(r.rating),
      csvEscape(r.date),
      csvEscape(r.content),
      csvEscape(r.response)
    ].join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  // Get business name from page title (via chrome.tabs)
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const pageTitle = tabs[0]?.title || 'reviews';
    const placeName = pageTitle.split(' - ')[0] || 'reviews';
    const cleanPlaceName = placeName.replace(/[^a-z0-9]/gi, '_');
    const date = new Date().toISOString().split('T')[0];
    const filename = `seo-saijo_${cleanPlaceName}_reviews_${date}.csv`;

    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    // Auto-close side panel after download
    setTimeout(() => {
      window.close();
    }, 500);
  });
}

// Attach download button handler
downloadBtn.addEventListener('click', downloadCSV);
