# SEO Saijo GBP Review Scraper - Chrome Extension

A Chrome extension to extract Google Business Profile reviews from Google Search and Google Maps.

## Features

- 🚀 One-click review extraction from Google Business listings
- 📊 Side panel interface with real-time progress updates
- 💾 CSV export 
- 🎯 Works on Google Search, Google Maps, and Knowledge Graph pages


## Installation

### Step 1: Download or Clone

Download this extension folder to your computer.

### Step 2: Load Extension in Chrome

- You should see "SEO Saijo GBP Review Scraper" in your extensions list

## Usage

### Basic Usage

1. **Navigate to a Google Business listing**:
   - Should work on Google Search and Google Maps 

2. **Click the extension icon** in your Chrome toolbar

3. **Wait for scraping to complete**:
   - The side panel will open automatically
   - You'll see real-time progress updates
   - Scraping time depending on review count

4. **Download the CSV**:
   - Click the "Download CSV" button when scraping completes
   - File will be saved to you PC


## CSV Output Format

The exported CSV contains 5 columns:

| Column | Description |
|--------|-------------|
| Name | Reviewer's name |
| Rating | Star rating (e.g., "5 stars") |
| Date | Review date (e.g., "2 weeks ago") |
| Review | Full review text |
| Response | Business owner's response (if any) |


## Troubleshooting

### Extension icon is grayed out / doesn't work

**Solution**: Make sure you're on a valid Google Search or Google Maps page with a business listing.

### "Something went wrong" error message

**Possible causes**:
- Google has changed their page structure (selectors may need updating)
- Page hasn't fully loaded yet (wait a few seconds and try again)
- Not on a business listing page

**Solution**: Check for an updated version at [saijogeorge.com/gbp-review-scraper/](https://saijogeorge.com/gbp-review-scraper/)

## Version History

### v1.0 (Current)
- Initial release

## Technical Details

- **Manifest Version**: 3 (Manifest V3)
- **Permissions**: activeTab, sidePanel, scripting, storage
- **Host Permissions**: `https://www.google.com/*`, `https://www.google.*/search*`, `https://www.google.*/maps*`
- **Browser Support**: Chrome 114+ (requires Side Panel API)
- **Dependencies**: None (pure vanilla JavaScript)

## Known Limitations

1. **Google structure changes**: If Google updates their HTML/CSS, selectors may need updating
2. **Rate limiting**: Scraping very large review sets (500+) may be slow


## Credits

**Created by**: [Saijo George](https://saijogeorge.com)

**Version**: 1.0

**Website**: [saijogeorge.com/gbp-review-scraper/](https://saijogeorge.com/gbp-review-scraper/)

## Support

For updates, bug reports, and support:
- Ping me on LinkedIn: [https://www.linkedin.com/in/saijogeorge](https://www.linkedin.com/in/saijogeorge)


**Note**: This extension is not affiliated with or endorsed by Google. Use responsibly and in accordance with Google's Terms of Service. This software is provided “as is”, without warranties of any kind. Use at your own discretion. I’m not responsible for any issues, changes, or outcomes resulting from its use.